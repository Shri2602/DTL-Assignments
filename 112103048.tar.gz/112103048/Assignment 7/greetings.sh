#! /bin/bash

greeting="Hi"
user=$(whoami)
date=$(date +%F)

echo "$greeting $user! Today is $date"
echo "Your bash shell version is : $BASH_VERSION.!"

