#! /bin/bash

echo
echo $*
echo
echo $@
echo
echo $#
echo
echo $-
echo
echo $$
echo
echo $!
echo
echo $0
echo
echo $_
echo
echo $?
echo
