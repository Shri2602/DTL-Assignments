# !/bin/bash -xv

echo ${19} ${8} ${18} ${9}
