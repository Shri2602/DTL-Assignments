#! /bin/bash

friend1=Hariom
friend2=Ishwar
friend3=Aditya

echo ${friend1}, ${friend2} and ${friend3} my buddys.
