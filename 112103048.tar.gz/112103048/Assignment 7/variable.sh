#! /bin/bash

name=" Shrikant Hamand "
echo My name is ${name}.


