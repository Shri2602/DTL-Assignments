# !/bin/bash -xv

# Bash Scripting

echo "Hello World!! I'm Shrikant."
