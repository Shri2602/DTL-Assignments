echo Shrikant Hamand
echo 112103048
echo DTl Assignment 7
